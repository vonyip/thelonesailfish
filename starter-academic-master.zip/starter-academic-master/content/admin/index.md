---
# Generate Wowchemy CMS
type: wowchemycms
outputs:
- wowchemycms_config
- HTML
---
